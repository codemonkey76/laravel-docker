<?php

namespace React\Promise\Stream;

if (!function_exists('React\Promise\Stream\buffer')) {
    require __DIR__ . '/functions.php';
}
