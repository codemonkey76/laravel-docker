<?php

namespace BeyondCode\LaravelWebSockets\WebSockets\Messages;

interface PusherMessage
{
    public function respond();
}
